En LaTeX skabelon til beamers af størrelse 16:9. Skabelonen består af en KU-mappe bestående af billedefiler, en billeder-mappe bestående af eksempler på billedefiler, en KUstyle.sty fil og en main.tex fil.

VIGTIGT! For at dokumentet kan compile, skal man benytte XeLaTeX eller LuaLaTeX som compiler. Dette kan gøres i Overleaf ved at gå til Menu -> Settings -> Compiler -> Vælg XeLaTeX/LuaLaTeX

For at ændre teksten på toplinje, skal man ændre kommandoen 'toplinje' inden document-miljøet

I skabelonen er den en forside og forskellige eksempler på slides. På forsiden kan man f.eks. ændre på hovedtitel, undertitlen og baggrundbilledet. 

Et nyt slide tilføjes ved at benytte frame-miljøet. Det er vigtigt at [hvid], [rod] eller [billede] er inkluderet efter \begin{frame}. [hvid], [rod] laver standard slides med den pågældende baggrundsfarve, mens [billede] tilføjer et baggrundsbillede. Hvis man benytter [billede] er det også vigtigt at bruge \setbeamertemplate{background} kommandoen til at angive baggrundsbilledet (i main.tex filen er der et eksempel på, hvordan dette helt præcist gøres).

Ønsker du at printe din beamer, så de fylder et helt A4 ark, kan flg. kode tilføjes inden \begin{document}

\usepackage{pgfpages}
\pgfpagesuselayout{resize to}[a4paper,landscape,border shrink=5mm]